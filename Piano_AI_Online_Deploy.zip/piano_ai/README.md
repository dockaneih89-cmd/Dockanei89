# Piano AI

AI-powered web application that turns uploaded audio into piano sheet music, MIDI, and realistic piano playback.

## Features

- Responsive landing page (mobile, tablet, desktop)
- Drag-and-drop upload (MP3, WAV, FLAC, OGG, M4A, max 25 MB)
- Real Spotify Basic Pitch transcription
- Music21 conversion to MusicXML (grand staff)
- OpenSheetMusicDisplay sheet music rendering
- Tone.js playback with Salamander Grand Piano samples
- Interactive virtual piano that highlights the actual transcribed notes
- Play / Pause / Stop / Restart + speed control
- Download MIDI, MusicXML, and PDF (print)
- Automatic cleanup of temporary files

## Project Structure

```
piano_ai/
├── backend/
│   ├── main.py
│   └── requirements.txt
├── frontend/
│   ├── index.html
│   ├── css/styles.css
│   └── js/script.js
├── uploads/          # temporary (auto-cleaned)
├── midi_output/      # temporary (auto-cleaned)
└── README.md
```

## Run Locally

### Prerequisites
- Python 3.9–3.11
- pip

### Setup

```bash
cd piano_ai/backend
python -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### Start the server

```bash
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

Open **http://localhost:8000**

On first load the Basic Pitch model is loaded. Transcription of a short clip typically takes a few seconds.

## Deploy

### Option 1: Any Linux server (systemd + nginx)

1. Copy the project to the server.
2. Create a virtualenv and install requirements.
3. Run with a process manager:

```bash
uvicorn main:app --host 0.0.0.0 --port 8000 --workers 1
```

Use 1 worker because the model is loaded in memory.

4. Put nginx in front for HTTPS and static caching.

### Option 2: Docker (example)

```dockerfile
FROM python:3.10-slim
WORKDIR /app
COPY . /app
RUN pip install --no-cache-dir -r backend/requirements.txt
EXPOSE 8000
CMD ["uvicorn", "backend.main:app", "--host", "0.0.0.0", "--port", "8000"]
```

### Environment notes
- `basic-pitch` on Linux uses TFLite by default.
- `numpy<2` is required (already pinned).
- Piano samples are loaded from `https://tonejs.github.io/audio/salamander/` (needs internet on the client).
- For production, consider restricting CORS and adding rate limiting.

## Tested Workflow

The following was verified:

- Invalid file type is rejected (HTTP 400)
- Valid WAV is transcribed by Basic Pitch
- MIDI and MusicXML are generated
- Note events are returned for playback
- Temporary files are deleted after the response
- Homepage loads and upload UI is present
- Playback controls and download buttons exist and are correctly disabled until results are ready

## Limitations

- PDF is produced via the browser print dialog of the rendered sheet music.
- Very long audio files will take longer and use more memory.
- Sheet music quality depends on the clarity of the source recording.
