# Deploy Piano AI online

This project needs a Python backend; it cannot be hosted as a plain static page.

## Deploy with Render

1. Create a GitHub repository and upload the contents of this `piano_ai` folder.
2. Sign in to Render and choose **New + → Blueprint**.
3. Connect the GitHub repository. Render will detect `render.yaml` and create the web service.
4. Wait for the build and deployment to finish. Open the `onrender.com` URL Render assigns to the service.

Notes:
- The first build can take several minutes because Basic Pitch and its dependencies are substantial.
- Free hosting may sleep when idle and may have memory limits. Audio transcription can fail on large or lengthy files if the host runs out of memory.
- The app currently accepts audio files up to 25 MB.
- The service needs outbound internet access for the browser piano samples and CDN libraries.
