document.addEventListener('DOMContentLoaded', () => {
    const fileInput = document.getElementById('file-input');
    const browseBtn = document.getElementById('browse-btn');
    const uploadArea = document.getElementById('upload-area');
    const processingStatus = document.getElementById('processing-status');
    const progressBar = document.getElementById('progress-bar');
    const statusText = document.getElementById('status-text');
    const errorMessage = document.getElementById('error-message');
    const resultsSection = document.getElementById('results-section');
    const scrollToUploadBtn = document.getElementById('scroll-to-upload');
    const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
    const navLinks = document.querySelector('.nav-links');

    const allowedTypes = ['audio/mpeg', 'audio/wav', 'audio/flac', 'audio/ogg', 'audio/mp4', 'audio/x-m4a'];
    const allowedExtensions = ['.mp3', '.wav', '.flac', '.ogg', '.m4a'];

    // Mobile menu toggle
    mobileMenuBtn.addEventListener('click', () => {
        navLinks.classList.toggle('active');
    });

    // Close menu on link click
    document.querySelectorAll('.nav-links a').forEach(link => {
        link.addEventListener('click', () => {
            navLinks.classList.remove('active');
        });
    });

    // Scroll to upload
    scrollToUploadBtn.addEventListener('click', () => {
        document.getElementById('upload-section').scrollIntoView({ behavior: 'smooth' });
    });

    // Browse button
    browseBtn.addEventListener('click', () => fileInput.click());

    // Click on upload area
    uploadArea.addEventListener('click', (e) => {
        if (e.target !== browseBtn && !browseBtn.contains(e.target)) {
            fileInput.click();
        }
    });

    // Drag and drop
    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
        uploadArea.addEventListener(eventName, preventDefaults, false);
    });

    function preventDefaults(e) {
        e.preventDefault();
        e.stopPropagation();
    }

    ['dragenter', 'dragover'].forEach(eventName => {
        uploadArea.addEventListener(eventName, () => uploadArea.classList.add('dragover'), false);
    });

    ['dragleave', 'drop'].forEach(eventName => {
        uploadArea.addEventListener(eventName, () => uploadArea.classList.remove('dragover'), false);
    });

    uploadArea.addEventListener('drop', handleDrop, false);
    fileInput.addEventListener('change', handleFileSelect);

    function handleDrop(e) {
        const dt = e.dataTransfer;
        const files = dt.files;
        if (files.length > 0) {
            handleFile(files[0]);
        }
    }

    function handleFileSelect(e) {
        if (e.target.files.length > 0) {
            handleFile(e.target.files[0]);
        }
    }

    function isValidFile(file) {
        const ext = '.' + file.name.split('.').pop().toLowerCase();
        return allowedExtensions.includes(ext) || allowedTypes.includes(file.type);
    }

    function handleFile(file) {
        errorMessage.hidden = true;
        resultsSection.hidden = true;

        if (!isValidFile(file)) {
            showError('Please upload a valid audio file (MP3, WAV, FLAC, OGG, or M4A).');
            return;
        }

        if (file.size > 25 * 1024 * 1024) {
            showError('File is too large. Maximum upload size is 25MB.');
            return;
        }

        uploadFile(file);
    }

    async function uploadFile(file) {
        processingStatus.hidden = false;
        progressBar.style.width = '10%';
        statusText.textContent = 'Uploading audio...';

        const formData = new FormData();
        formData.append('file', file);

        try {
            // Simulated progress while the request runs (transcription takes time)
            let progress = 10;
            const progressInterval = setInterval(() => {
                if (progress < 85) {
                    progress += Math.random() * 8;
                    progressBar.style.width = progress + '%';
                    if (progress > 30) statusText.textContent = 'Analyzing with Basic Pitch...';
                    if (progress > 60) statusText.textContent = 'Extracting notes and generating MIDI...';
                }
            }, 400);

            const response = await fetch('/api/transcribe', {
                method: 'POST',
                body: formData
            });

            clearInterval(progressInterval);

            if (!response.ok) {
                let errorMsg = 'Transcription failed';
                try {
                    const errorData = await response.json();
                    errorMsg = errorData.detail || errorMsg;
                } catch (_) {
                    errorMsg = `Server error (${response.status})`;
                }
                throw new Error(errorMsg);
            }

            progressBar.style.width = '100%';
            statusText.textContent = 'Rendering sheet music...';

            const data = await response.json();
            const noteCount = data.note_count || 0;
            const originalName = data.original_filename || file.name;

            // MIDI blob
            const midiBytes = Uint8Array.from(atob(data.midi_base64), c => c.charCodeAt(0));
            const midiBlob = new Blob([midiBytes], { type: 'audio/midi' });
            const midiUrl = URL.createObjectURL(midiBlob);

            // MusicXML
            const musicxml = data.musicxml;
            const xmlBlob = new Blob([musicxml], { type: 'application/vnd.recordare.musicxml+xml' });
            const xmlUrl = URL.createObjectURL(xmlBlob);

            showResults(midiUrl, xmlUrl, musicxml, originalName, noteCount, data.notes || []);

            setTimeout(() => {
                resultsSection.scrollIntoView({ behavior: 'smooth' });
            }, 300);

        } catch (err) {
            progressBar.style.width = '0%';
            showError(err.message || 'An error occurred during transcription. Please try again.');
            processingStatus.hidden = true;
        }
    }

    let currentOsmd = null;
    let pianoSampler = null;
    let scheduledNotes = [];
    let isPlaying = false;
    let playbackTimer = null;
    let currentNotes = [];

    function showResults(midiUrl, xmlUrl, musicxml, originalName, noteCount, notes) {
        resultsSection.hidden = false;
        currentNotes = notes;

        const noteEl = resultsSection.querySelector('.results-note');
        if (noteEl) {
            noteEl.textContent = `Successfully transcribed "${originalName}". Detected ${noteCount} notes.`;
            noteEl.style.fontStyle = 'normal';
            noteEl.style.color = 'var(--lavender)';
        }

        const midiBtn = document.getElementById('download-midi');
        if (midiBtn) {
            midiBtn.disabled = false;
            midiBtn.style.cursor = 'pointer';
            midiBtn.style.opacity = '1';
            midiBtn.onclick = () => downloadBlob(midiUrl, originalName.replace(/\.[^/.]+$/, '') + '_piano.mid');
        }

        const xmlBtn = document.getElementById('download-musicxml');
        if (xmlBtn) {
            xmlBtn.disabled = false;
            xmlBtn.style.cursor = 'pointer';
            xmlBtn.style.opacity = '1';
            xmlBtn.onclick = () => downloadBlob(xmlUrl, originalName.replace(/\.[^/.]+$/, '') + '.musicxml');
        }

        const pdfBtn = document.getElementById('download-pdf');
        if (pdfBtn) {
            pdfBtn.disabled = false;
            pdfBtn.style.cursor = 'pointer';
            pdfBtn.style.opacity = '1';
            pdfBtn.onclick = () => printSheetMusic();
        }

        renderSheetMusic(musicxml).then(() => {
            buildVirtualPiano(notes);
            setupPlayback(notes);
        });
    }

    function downloadBlob(url, filename) {
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
    }

    async function renderSheetMusic(musicxml) {
        const container = document.getElementById('sheet-music-container');
        if (!container || typeof OpenSheetMusicDisplay === 'undefined') {
            container.innerHTML = '<div class="placeholder-content">Sheet music renderer not available</div>';
            return;
        }

        container.innerHTML = '';
        currentOsmd = new OpenSheetMusicDisplay.OpenSheetMusicDisplay(container, {
            autoResize: true,
            backend: 'svg',
            drawTitle: false,
            drawComposer: false,
            drawCredits: false,
            pageFormat: 'Endless',
            drawingParameters: 'compact',
        });

        try {
            await currentOsmd.load(musicxml);
            currentOsmd.render();
            if (currentOsmd.cursor) {
                currentOsmd.cursor.show();
                currentOsmd.cursor.reset();
            }
        } catch (err) {
            console.error(err);
            container.innerHTML = '<div class="placeholder-content">Could not render sheet music</div>';
        }
    }

    async function setupPlayback(notes) {
        const status = document.getElementById('playback-status');
        const playBtn = document.getElementById('btn-play');
        const pauseBtn = document.getElementById('btn-pause');
        const stopBtn = document.getElementById('btn-stop');
        const restartBtn = document.getElementById('btn-restart');
        const speedSelect = document.getElementById('speed-select');

        if (!notes || notes.length === 0) {
            status.textContent = 'No notes to play.';
            return;
        }

        status.textContent = 'Loading piano samples...';

        try {
            if (typeof Tone === 'undefined') {
                throw new Error('Tone.js not loaded');
            }

            await Tone.start();

            pianoSampler = new Tone.Sampler({
                urls: {
                    A0: "A0.mp3", C1: "C1.mp3", "D#1": "Ds1.mp3", "F#1": "Fs1.mp3",
                    A1: "A1.mp3", C2: "C2.mp3", "D#2": "Ds2.mp3", "F#2": "Fs2.mp3",
                    A2: "A2.mp3", C3: "C3.mp3", "D#3": "Ds3.mp3", "F#3": "Fs3.mp3",
                    A3: "A3.mp3", C4: "C4.mp3", "D#4": "Ds4.mp3", "F#4": "Fs4.mp3",
                    A4: "A4.mp3", C5: "C5.mp3", "D#5": "Ds5.mp3", "F#5": "Fs5.mp3",
                    A5: "A5.mp3", C6: "C6.mp3", "D#6": "Ds6.mp3", "F#6": "Fs6.mp3",
                    A6: "A6.mp3", C7: "C7.mp3", "D#7": "Ds7.mp3", "F#7": "Fs7.mp3",
                    A7: "A7.mp3", C8: "C8.mp3"
                },
                release: 1,
                baseUrl: "https://tonejs.github.io/audio/salamander/",
                onload: () => {
                    status.textContent = `Ready – ${notes.length} notes from transcription`;
                    [playBtn, pauseBtn, stopBtn, restartBtn, speedSelect].forEach(el => el.disabled = false);
                }
            }).toDestination();

            // Schedule notes from actual transcription
            Tone.Transport.cancel();
            scheduledNotes = [];

            notes.forEach(n => {
                const midiNote = Tone.Frequency(n.pitch, "midi").toNote();
                const eventId = Tone.Transport.schedule((time) => {
                    pianoSampler.triggerAttackRelease(midiNote, n.duration, time, n.velocity / 127);
                    // Highlight key on the virtual piano
                    Tone.Draw.schedule(() => {
                        highlightPianoKey(n.pitch, n.duration);
                    }, time);
                }, n.start);
                scheduledNotes.push(eventId);
            });

            // Controls
            playBtn.onclick = async () => {
                if (Tone.Transport.state !== 'started') {
                    await Tone.start();
                    Tone.Transport.start();
                    isPlaying = true;
                    status.textContent = 'Playing...';
                    startCursorSync();
                }
            };

            pauseBtn.onclick = () => {
                Tone.Transport.pause();
                isPlaying = false;
                status.textContent = 'Paused';
                stopCursorSync();
            };

            stopBtn.onclick = () => {
                Tone.Transport.stop();
                Tone.Transport.seconds = 0;
                isPlaying = false;
                status.textContent = 'Stopped';
                stopCursorSync();
                clearAllKeyHighlights();
                if (currentOsmd && currentOsmd.cursor) {
                    currentOsmd.cursor.reset();
                }
            };

            restartBtn.onclick = async () => {
                Tone.Transport.stop();
                Tone.Transport.seconds = 0;
                clearAllKeyHighlights();
                if (currentOsmd && currentOsmd.cursor) currentOsmd.cursor.reset();
                await Tone.start();
                Tone.Transport.start();
                isPlaying = true;
                status.textContent = 'Playing...';
                startCursorSync();
            };

            speedSelect.onchange = () => {
                Tone.Transport.bpm.value = 120 * parseFloat(speedSelect.value);
            };

        } catch (err) {
            console.error(err);
            status.textContent = 'Playback error: ' + err.message;
        }
    }

    function highlightNote(startTime) {
        // Simple time-based cursor advance (approximate sync)
        if (!currentOsmd || !currentOsmd.cursor) return;
        // Cursor is advanced by the sync loop
    }

    let activeKeyTimeouts = {};

    function buildVirtualPiano(notes) {
        const container = document.getElementById('virtual-piano');
        if (!container) return;

        container.innerHTML = '';
        const keysWrap = document.createElement('div');
        keysWrap.className = 'piano-keys';

        // Dynamic range based on actual notes (with padding), fallback to C3–C6
        let startMidi = 48, endMidi = 84;
        if (notes && notes.length) {
            const pitches = notes.map(n => n.pitch);
            startMidi = Math.max(36, Math.min(...pitches) - 2);
            endMidi = Math.min(96, Math.max(...pitches) + 2);
            // Align to white keys
            while (startMidi % 12 !== 0) startMidi--;
            while (endMidi % 12 !== 0) endMidi++;
        }

        const whiteKeys = [];
        const blackKeys = [];

        for (let midi = startMidi; midi <= endMidi; midi++) {
            const isBlack = [1, 3, 6, 8, 10].includes(midi % 12);
            const key = document.createElement('div');
            key.dataset.midi = midi;
            key.className = isBlack ? 'black-key' : 'white-key';
            if (isBlack) blackKeys.push({ el: key, midi });
            else {
                whiteKeys.push({ el: key, midi });
                keysWrap.appendChild(key);
            }
        }
        blackKeys.forEach(bk => keysWrap.appendChild(bk.el));
        container.appendChild(keysWrap);

        // Position black keys after layout
        setTimeout(() => {
            const wrapRect = keysWrap.getBoundingClientRect();
            blackKeys.forEach(bk => {
                const prev = whiteKeys.find(w => w.midi === bk.midi - 1) || whiteKeys.find(w => w.midi === bk.midi - 2);
                if (prev) {
                    const r = prev.el.getBoundingClientRect();
                    bk.el.style.left = (r.right - wrapRect.left - 9) + 'px';
                }
            });
        }, 50);
    }

    function highlightPianoKey(midi, duration) {
        const key = document.querySelector(`#virtual-piano [data-midi="${midi}"]`);
        if (!key) return;
        key.classList.add('active');

        // Clear previous timeout for this key
        if (activeKeyTimeouts[midi]) clearTimeout(activeKeyTimeouts[midi]);
        activeKeyTimeouts[midi] = setTimeout(() => {
            key.classList.remove('active');
            delete activeKeyTimeouts[midi];
            updateActiveNotesDisplay();
        }, duration * 1000);

        updateActiveNotesDisplay();
    }

    function updateActiveNotesDisplay() {
        const el = document.getElementById('active-notes');
        if (!el) return;
        const active = Array.from(document.querySelectorAll('#virtual-piano .active'))
            .map(k => Tone.Frequency(parseInt(k.dataset.midi), "midi").toNote())
            .filter(Boolean);
        el.textContent = active.length ? 'Playing: ' + active.join(', ') : '';
    }

    function clearAllKeyHighlights() {
        document.querySelectorAll('#virtual-piano .active').forEach(k => k.classList.remove('active'));
        Object.values(activeKeyTimeouts).forEach(clearTimeout);
        activeKeyTimeouts = {};
        const el = document.getElementById('active-notes');
        if (el) el.textContent = '';
    }

    function startCursorSync() {
        stopCursorSync();
        noteIndex = 0;
        if (currentOsmd && currentOsmd.cursor) {
            currentOsmd.cursor.reset();
            currentOsmd.cursor.show();
        }
        playbackTimer = setInterval(() => {
            if (!isPlaying || !currentOsmd || !currentOsmd.cursor || !currentNotes.length) return;
            const t = Tone.Transport.seconds;
            while (noteIndex < currentNotes.length && currentNotes[noteIndex].start <= t) {
                try {
                    currentOsmd.cursor.next();
                } catch (e) {}
                noteIndex++;
            }
        }, 50);
    }

    function stopCursorSync() {
        if (playbackTimer) {
            clearInterval(playbackTimer);
            playbackTimer = null;
        }
    }

    function printSheetMusic() {
        const container = document.getElementById('sheet-music-container');
        if (!container || !container.querySelector('svg')) {
            alert('No sheet music to print.');
            return;
        }
        const printWindow = window.open('', '_blank');
        printWindow.document.write(`
            <html>
            <head>
                <title>Piano AI Sheet Music</title>
                <style>
                    body { margin: 20px; background: white; }
                    svg { max-width: 100%; height: auto; }
                    @media print { body { margin: 0; } }
                </style>
            </head>
            <body>
                ${container.innerHTML}
                <script>window.onload = () => { window.print(); setTimeout(() => window.close(), 500); }<\/script>
            </body>
            </html>
        `);
        printWindow.document.close();
    }

    function showError(message) {
        errorMessage.textContent = message;
        errorMessage.hidden = false;
    }

    // Smooth scroll for nav links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            const target = document.querySelector(targetId);
            if (target) {
                e.preventDefault();
                target.scrollIntoView({ behavior: 'smooth' });
            }
        });
    });
});
