from fastapi import FastAPI, File, UploadFile, HTTPException, BackgroundTasks
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
import shutil
from pathlib import Path
import uuid
import os
import base64
import logging

from basic_pitch.inference import predict, Model
from basic_pitch import ICASSP_2022_MODEL_PATH
from music21 import converter, stream, clef, meter, note, chord

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(title="Piano AI", description="AI-powered piano sheet music generator")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

BASE_DIR = Path(__file__).resolve().parent.parent
FRONTEND_DIR = BASE_DIR / "frontend"
UPLOAD_DIR = BASE_DIR / "uploads"
MIDI_DIR = BASE_DIR / "midi_output"
UPLOAD_DIR.mkdir(exist_ok=True)
MIDI_DIR.mkdir(exist_ok=True)
STATIC_DIR = BASE_DIR / "static"
STATIC_DIR.mkdir(exist_ok=True)

logger.info("Loading Basic Pitch model...")
basic_pitch_model = Model(ICASSP_2022_MODEL_PATH)
logger.info("Basic Pitch model loaded successfully.")

MAX_UPLOAD_SIZE = 25 * 1024 * 1024
ALLOWED_EXTENSIONS = {".mp3", ".wav", ".flac", ".ogg", ".m4a"}

app.mount("/css", StaticFiles(directory=FRONTEND_DIR / "css"), name="css")
app.mount("/js", StaticFiles(directory=FRONTEND_DIR / "js"), name="js")
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

@app.get("/")
async def root():
    return FileResponse(FRONTEND_DIR / "index.html")

def cleanup_files(*paths):
    for p in paths:
        try:
            if p and Path(p).exists():
                Path(p).unlink()
                logger.info(f"Cleaned up: {p}")
        except Exception as e:
            logger.warning(f"Failed to clean up {p}: {e}")

def midi_to_musicxml(midi_path: Path) -> str:
    """Convert MIDI to MusicXML using Music21, with proper piano grand staff."""
    score = converter.parse(str(midi_path))
    
    # Ensure we have a Score
    if not isinstance(score, stream.Score):
        new_score = stream.Score()
        new_score.append(score)
        score = new_score

    # Set up piano grand staff (treble + bass) if not already present
    parts = score.parts
    if len(parts) == 0:
        parts = [score]

    # Try to create a clean piano layout
    piano_score = stream.Score()
    piano_score.insert(0, meter.TimeSignature('4/4'))
    
    # Merge all notes into one part then split by pitch for treble/bass
    all_notes = []
    for part in parts:
        for el in part.flatten().notesAndRests:
            all_notes.append(el)

    if not all_notes:
        # Empty score fallback
        treble = stream.Part()
        treble.insert(0, clef.TrebleClef())
        treble.insert(0, meter.TimeSignature('4/4'))
        piano_score.append(treble)
    else:
        # Sort by offset
        all_notes.sort(key=lambda n: n.offset)
        
        treble = stream.Part()
        bass = stream.Part()
        treble.insert(0, clef.TrebleClef())
        bass.insert(0, clef.BassClef())
        treble.insert(0, meter.TimeSignature('4/4'))
        bass.insert(0, meter.TimeSignature('4/4'))

        for n in all_notes:
            # Simple pitch-based staff assignment (middle C and above -> treble)
            if hasattr(n, 'pitch'):
                if n.pitch.midi >= 60:
                    treble.insert(n.offset, n)
                else:
                    bass.insert(n.offset, n)
            elif isinstance(n, chord.Chord):
                # Assign chord based on highest pitch
                if n.pitches and max(p.midi for p in n.pitches) >= 60:
                    treble.insert(n.offset, n)
                else:
                    bass.insert(n.offset, n)
            else:
                # rests go to both or treble
                treble.insert(n.offset, n)
                bass.insert(n.offset, n)

        piano_score.append(treble)
        if any(True for _ in bass.notesAndRests):
            piano_score.append(bass)

    # Write to MusicXML string
    xml_path = midi_path.with_suffix('.musicxml')
    piano_score.write('musicxml', fp=str(xml_path))
    xml_content = xml_path.read_text(encoding='utf-8')
    xml_path.unlink(missing_ok=True)
    return xml_content

@app.post("/api/transcribe")
async def transcribe_audio(
    background_tasks: BackgroundTasks,
    file: UploadFile = File(...)
):
    if not file.filename:
        raise HTTPException(status_code=400, detail="No filename provided")

    ext = Path(file.filename).suffix.lower()
    if ext not in ALLOWED_EXTENSIONS:
        raise HTTPException(status_code=400, detail="Unsupported file type. Allowed: MP3, WAV, FLAC, OGG, M4A")

    contents = await file.read()
    if len(contents) > MAX_UPLOAD_SIZE:
        raise HTTPException(status_code=413, detail=f"File too large. Maximum size is {MAX_UPLOAD_SIZE // (1024*1024)} MB.")

    unique_id = str(uuid.uuid4())
    audio_path = UPLOAD_DIR / f"{unique_id}{ext}"
    midi_path = MIDI_DIR / f"{unique_id}.mid"

    try:
        with open(audio_path, "wb") as buffer:
            buffer.write(contents)

        logger.info(f"Saved upload: {audio_path}")

        logger.info("Running Basic Pitch transcription...")
        model_output, midi_data, note_events = predict(
            str(audio_path),
            model_or_model_path=basic_pitch_model,
            onset_threshold=0.5,
            frame_threshold=0.3,
            minimum_note_length=127.70,
            melodia_trick=True,
        )

        note_count = len(note_events) if note_events else 0
        logger.info(f"Notes detected: {note_count}")

        # Prepare structured notes for frontend playback
        notes_for_playback = []
        if note_events:
            for ev in note_events:
                # note_events: (start_time, end_time, pitch_midi, amplitude, [pitch_bends])
                start, end, pitch, amp = ev[0], ev[1], ev[2], ev[3]
                notes_for_playback.append({
                    "pitch": int(pitch),
                    "start": float(start),
                    "duration": float(max(0.05, end - start)),
                    "velocity": int(max(1, min(127, round(amp * 127))))
                })

        midi_data.write(str(midi_path))

        logger.info("Generating MusicXML...")
        musicxml = midi_to_musicxml(midi_path)

        midi_b64 = base64.b64encode(midi_path.read_bytes()).decode('ascii')

        background_tasks.add_task(cleanup_files, audio_path, midi_path)

        return JSONResponse({
            "status": "success",
            "note_count": note_count,
            "original_filename": file.filename,
            "midi_base64": midi_b64,
            "musicxml": musicxml,
            "notes": notes_for_playback,
        })

    except HTTPException:
        cleanup_files(audio_path, midi_path)
        raise
    except Exception as e:
        logger.exception("Transcription failed")
        cleanup_files(audio_path, midi_path)
        raise HTTPException(status_code=500, detail=f"Transcription failed: {str(e)}")

@app.get("/api/health")
async def health():
    return {"status": "ok", "service": "Piano AI", "phase": "full-transcription-playback", "model_loaded": True}

