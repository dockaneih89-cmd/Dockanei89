#!/bin/bash
# Simple launcher for Piano AI
cd "$(dirname "$0")/backend"
if [ ! -d "venv" ]; then
  echo "Creating virtual environment..."
  python3 -m venv venv
  source venv/bin/activate
  pip install -r requirements.txt
else
  source venv/bin/activate
fi
echo "Starting Piano AI at http://localhost:8000"
uvicorn main:app --host 0.0.0.0 --port 8000
